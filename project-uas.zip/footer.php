	

	<!--awal footer-->
		<div class="row">
			<div class="col-md-12">
				<center>Copyright &copy 2024  Website SMA N.1 MEDAN<span class="glyphicon glyphicon-heart"></span> Created By RISKAMAWARNI LAIA
				</center>
			</div>
			</div>
		</div><!-- Akhir footer-->



				
<script src="bootstrap/js/jQuery.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>