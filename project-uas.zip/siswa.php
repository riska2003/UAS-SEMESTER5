<?php include "header.php"; ?>
		
		<!-- Awal Page -->
		<div class="container">
		<!-- Awal baris -->
		<div class="row">
			<div class="col-md-8"><!-- Awal Kolom Pertama -->
			<div class="panel panel-default">
				<div class="panel-body">
				<h2 style="text-muted"><span class="glyphicon glyphicon-list"></span> Data Siswa</h2>
					<table class="table table-bordered table-hover" id="data-table">
						<thead>
						<tr>
							
							<th>Nama Lengkap</th>
							<th>NIS</th>
							<th>Jenis Kelamin</th>
							<th>Jurusan</th>
						</tr>
						</thead>
						<?php

						include "koneksi.php";
						$sql=$koneksi->query("select * from siswa order by nis ASC");

						while($row= $sql->fetch_assoc()){
						?>
						<tr>
							<td><?php echo $row['nama']?></td>
							<td><?php echo $row['nis']?></td>
							<td><?php echo $row['jenis_kelamin']?></td>
							<td><?php echo $row['jurusan']?></td>
						</tr>
						<?php } ?>
						</table>
				</div>
      </div>
			</div><!-- Akhir Kolom Pertama -->
			
			<div class="col-md-4"><!-- Awal kolom kedua -->
			<div class="panel panel-default">
				<div class="panel-body">
				<h2 style="text-muted"><span class="glyphicon glyphicon-tasks"></span>Info Lainnya</h2>
				<h4>SMA NEGERI 1 MEDAN</h4>
				<img src="images/riska1.jpg" class="img-thumbnail img-responsive">
				<p>Mari gabung bersama kami dalam mencapai cita-cita setinggi langit dan menjadi anak kebanggaan orang tua,serta mewujudkan mimpi dengan tiada hentinya.
      </div>
			</div><!-- Akhir Kolom Kedua -->
		</div><!-- Akhir Baris -->
		</div><!--  Akhir Page -->
		<?php include "footer.php";?>