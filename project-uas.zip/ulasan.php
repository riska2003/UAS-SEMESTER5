<?php include "header.php"; ?>


			</div><!--awal ulasan-->
	<div id="ulasan.php">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiple Images in One Table</title>
    <style>
        table {
            border-collapse: collapse;
        }
        td {
            padding: 5px;
            border: 1px solid #ddd;
        }
        img {
            max-width: 90%;
            height: auto;
            display: block;
            margin: 0 auto;
        }
    </style>
</head>
<body>

 <table>
        <tr>
            <td><img src="bahajpg.jpg" alt="Gambar 1"></td>
            <td><img src="sekolah1.jpg" alt="Gambar 2"></td>
            <td><img src="piagam.jpg" alt="Gambar 3"></td>
            <td><img src="belajar.jpg" alt="Gambar 4"></td>
        </tr>
        <tr>
            <td><img src="ttramah2.jpg" alt="Gambar 5"></td>
            <td><img src="guru.jpeg" alt="Gambar 6"></td>
            <td><img src="smsa5.jpg" alt="Gambar 7"></td>
            <td><img src="baketcwk.jpeg" alt="Gambar 8"></td>
        </tr>
    </table>



</body>
</html>


			<?php include "footer.php";?>
			