
<?php include "header.php"; ?>

<!--awal about-->
	<div class="heading">
		<br>
		<h3>TENTANG SMA N.1 MEDAN</h3>
		<div id="about.php">
		<div class="About">
		<img src="riska1.jpg">
		<div class="content">
		<p><h4>SMA  N.1 MEDAN  atau smansa medan,terletak dijalan Teuku Cik Dik Tiro nmr.1 medan,sumatera utara.Berdiri sejak tahun 1950,SMA N.1 Medan melahirkan banyak pemimpin sipil dan militer ditingkat  regional maupun nasional.Berdiri di jantung pusat kota yang kosmopolitan,smansa medan mendidik siswa dengan disiplin ketat demi mengabadikan  ilmu untuk kepentingan bangsa dan negara. Salah satu ciri khas unik yang dikenal dari Smansa Medan ialah historisnya sebagai almamater para gubernur dan jenderal.</h5>
		</p>
		</div>
	</div>
</div>
	<!--akhir about-->

	<?php include "footer.php";?>