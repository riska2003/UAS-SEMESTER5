<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

$nama=$_POST['nama'];
$nis=$_POST['nis'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$jurusan=$_POST['jurusan'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into siswa(nama,nis,jenis_kelamin,jurusan) 
                        values ('$nama', '$nis', '$jenis_kelamin', '$jurusan')");

if($simpan==true){

    header("location:tampil-siswa.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>