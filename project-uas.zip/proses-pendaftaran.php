
<?php

include "koneksi.php";
$nik = $koneksi->real_escape_string($_POST['nik']); 
$nama = $koneksi->real_escape_string($_POST['nama']); 
$tanggal_lahir = $koneksi->real_escape_string($_POST['tanggal_lahir']); 
$jenis_kelamin = $koneksi->real_escape_string($_POST['jenis_kelamin']); 
$asal_sekolah = $koneksi->real_escape_string($_POST['asal_sekolah']); 
$telepon = $koneksi->real_escape_string($_POST['telepon']); 
$alamat = $koneksi->real_escape_string($_POST['alamat']); 
$jurusan = $koneksi->real_escape_string($_POST['jurusan']); 


$simpan=$koneksi->query("insert into pendaftaran(nik,nama,tanggal_lahir,jenis_kelamin,asal_sekolah,telepon,alamat,jurusan) 
                        values ('$nik', '$nama', '$tanggal_lahir','$jenis_kelamin','$asal_sekolah','$telepon','$alamat','$jurusan')");

if($simpan==true){

    header("location:pendaftaran.php?pesan=inputBerhasil");
} else{
    echo "Error";
}

?>